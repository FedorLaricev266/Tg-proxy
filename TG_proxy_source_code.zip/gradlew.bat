@echo off
setlocal EnableExtensions
set GRADLE_VERSION=8.7
set DIR=%~dp0

rem Android Gradle Plugin 8.x requires JDK 17. Prefer Android Studio's bundled JBR.
if not defined JAVA_HOME (
  if exist "C:\Program Files\Android\Android Studio\jbr\bin\java.exe" set "JAVA_HOME=C:\Program Files\Android\Android Studio\jbr"
)
if not defined JAVA_HOME (
  if exist "C:\Program Files\Android\Android Studio\jre\bin\java.exe" set "JAVA_HOME=C:\Program Files\Android\Android Studio\jre"
)
if not defined JAVA_HOME (
  if exist "%LOCALAPPDATA%\Programs\Android Studio\jbr\bin\java.exe" set "JAVA_HOME=%LOCALAPPDATA%\Programs\Android Studio\jbr"
)
if defined JAVA_HOME (
  set "PATH=%JAVA_HOME%\bin;%PATH%"
  echo Using JAVA_HOME=%JAVA_HOME%
) else (
  echo JAVA_HOME is not set. Android Gradle Plugin requires JDK 17.
  echo In Android Studio set Gradle JDK to jbr, or install JDK 17 and set JAVA_HOME.
)

set GRADLE_HOME=%DIR%.gradle\local-gradle\gradle-%GRADLE_VERSION%
set GRADLE_BAT=%GRADLE_HOME%\bin\gradle.bat

if exist "%GRADLE_BAT%" goto run_gradle

echo Gradle %GRADLE_VERSION% not found. Downloading it to .gradle\local-gradle ...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $v='%GRADLE_VERSION%'; $dir='%DIR%'; $base=Join-Path $dir '.gradle\local-gradle'; New-Item -ItemType Directory -Force -Path $base | Out-Null; $zip=Join-Path $base ('gradle-' + $v + '-bin.zip'); $url='https://services.gradle.org/distributions/gradle-' + $v + '-bin.zip'; Write-Host ('Downloading ' + $url); Invoke-WebRequest -Uri $url -OutFile $zip; Expand-Archive -Force -Path $zip -DestinationPath $base"
if errorlevel 1 (
  echo Failed to download Gradle. You can also build from Android Studio: Build ^> Build APK^(s^).
  exit /b 1
)

:run_gradle
call "%GRADLE_BAT%" %*
