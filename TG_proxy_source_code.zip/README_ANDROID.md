# TG proxy by Jr.Larzyk

Версия с главным экраном из одной кнопки, Secret на устройство и расширенными настройками.

## Что нового

- Secret генерируется один раз при первом запуске и хранится в SharedPreferences только на устройстве.
- Первое нажатие на большую кнопку запускает прокси и автоматически открывает Telegram-ссылку.
- При первом запуске показываются onboarding-карточки с объяснением работы.
- В настройках доступны порт, Cloudflare-домен, таймаут подключения и idle timeout.
- Есть действия: открыть Telegram, скопировать ссылку, показать логи, сгенерировать новый Secret.

## Сборка

```powershell
cd C:\Projects\tgws_android_app
$env:JAVA_HOME = "C:\Program Files\Android\Android Studio\jbr"
$env:Path = "$env:JAVA_HOME\bin;$env:Path"
.\gradlew.bat assembleDebug
```

APK: `app\build\outputs\apk\debug\app-debug.apk`
