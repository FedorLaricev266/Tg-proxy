# TG proxy by Jr.Larzyk

Android-приложение для запуска локального Telegram MTProto proxy на устройстве.

Проект сделан как Android-порт идеи `tg-ws-proxy`: Telegram подключается к локальному прокси на `127.0.0.1`, а приложение пробрасывает трафик через WebSocket/WSS и Cloudflare-домен.

## Возможности

- Android-приложение без Python и Chaquopy.
- Нативная Java-реализация прокси.
- AES через `javax.crypto.Cipher`.
- Большая кнопка запуска/остановки.
- Secret генерируется один раз на устройстве.
- При первом запуске открывается Telegram-ссылка.
- Настройки порта, Cloudflare-домена и таймаутов.
- Режим максимальной скорости: `TCP_NODELAY`, увеличенные буферы, меньше логирования в hot path.
- Foreground Service для стабильной работы в фоне.

## Как это работает

```text
Telegram → 127.0.0.1:1443 → TG proxy by Jr.Larzyk → WSS/Cloudflare → Telegram
```

Приложение запускает локальный прокси на телефоне. Telegram подключается к `127.0.0.1`, а дальше приложение отправляет трафик через WebSocket/WSS.

## Сборка APK на Windows

Нужна Android Studio.

```powershell
cd C:\Projects\tgws_android_app
$env:JAVA_HOME = "C:\Program Files\Android\Android Studio\jbr"
$env:Path = "$env:JAVA_HOME\bin;$env:Path"
.\gradlew.bat assembleDebug
```

Готовый APK:

```text
app\build\outputs\apk\debug\app-debug.apk
```

## Сборка на Linux/macOS

```bash
./gradlew assembleDebug
```

## Установка через ADB

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Настройки

В приложении можно изменить:

- локальный порт;
- Cloudflare-домен;
- connect timeout;
- idle timeout;
- Secret устройства;
- открыть Telegram-ссылку;
- скопировать Telegram-ссылку.

## Важно

Для работы обхода нужен рабочий Cloudflare/WSS-домен, совместимый с прокси-серверной частью. Если домен не работает или заблокирован, Telegram не подключится.

## Энергопотребление

Для меньшего расхода батареи:

1. Укажи стабильный Cloudflare-домен.
2. Не ставь слишком маленький idle timeout.
3. Отключи агрессивную экономию батареи для приложения, чтобы Android не пересоздавал соединение постоянно.

## Лицензия

MIT. См. файл [LICENSE](LICENSE).

## Благодарности

Проект основан на идее и протоколе `tg-ws-proxy` от Flowseal, который распространяется под MIT License.
