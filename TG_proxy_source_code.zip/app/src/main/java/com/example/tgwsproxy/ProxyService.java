package com.example.tgwsproxy;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import android.content.pm.ServiceInfo;

public class ProxyService extends Service {
    public static final String ACTION_START = "START";
    public static final String ACTION_STOP = "STOP";
    public static final String EXTRA_HOST = "host";
    public static final String EXTRA_PORT = "port";
    public static final String EXTRA_SECRET = "secret";
    public static final String EXTRA_CF_DOMAIN = "cf_domain";
    public static final String EXTRA_CONNECT_TIMEOUT = "connect_timeout";
    public static final String EXTRA_IDLE_TIMEOUT = "idle_timeout";
    private static final String CHANNEL_ID = "tg_ws_proxy";
    private static final FastMtprotoProxy proxy = new FastMtprotoProxy();

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : ACTION_START;
        if (ACTION_STOP.equals(action)) {
            proxy.stop();
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        }
        startProxyForeground("Прокси запускается…");
        new Thread(() -> {
            try {
                String host = intent.getStringExtra(EXTRA_HOST);
                if (host == null || host.isEmpty()) host = "127.0.0.1";
                int port = intent.getIntExtra(EXTRA_PORT, 1443);
                String secret = intent.getStringExtra(EXTRA_SECRET);
                if (secret == null) secret = "";
                String cfDomain = intent.getStringExtra(EXTRA_CF_DOMAIN);
                if (cfDomain == null) cfDomain = "";
                int connectTimeout = intent.getIntExtra(EXTRA_CONNECT_TIMEOUT, 3500);
                int idleTimeout = intent.getIntExtra(EXTRA_IDLE_TIMEOUT, 180000);
                String link = proxy.start(host, port, secret, cfDomain, connectTimeout, idleTimeout);
                updateNotification("WS/CF прокси работает: " + host + ":" + port);
                Log.i("TGWS", "Link: " + link);
            } catch (Exception e) {
                Log.e("TGWS", "Start failed", e);
                updateNotification("Ошибка запуска: " + e.getMessage());
            }
        }, "proxy-start").start();
        return START_STICKY;
    }

    public static String getLink() { return proxy.getLink(); }
    public static String getStatus() { return proxy.getStatus(); }
    public static String getLogs() { return proxy.getLogs(); }

    private void startProxyForeground(String text) {
        Notification n = notification(text);
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(1, n);
        }
    }

    private Notification notification(String text) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return b.setContentTitle("TG proxy by Jr.Larzyk").setContentText(text).setSmallIcon(R.drawable.ic_stat_tgproxy).setOngoing(true).setOnlyAlertOnce(true).setCategory(Notification.CATEGORY_SERVICE).setPriority(Notification.PRIORITY_MIN).build();
    }
    private void updateNotification(String text) {
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(1, notification(text));
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "TG proxy by Jr.Larzyk", NotificationManager.IMPORTANCE_MIN);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }
    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onDestroy() { proxy.stop(); super.onDestroy(); }
}
