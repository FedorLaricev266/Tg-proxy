package com.example.tgwsproxy;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.security.SecureRandom;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BG_TOP = Color.rgb(5, 24, 53);
    private static final int BG_BOTTOM = Color.rgb(0, 6, 18);
    private static final int TEXT = Color.rgb(246, 250, 255);
    private static final int MUTED = Color.rgb(155, 176, 207);
    private static final int PRIMARY = Color.rgb(0, 136, 204);
    private static final int GREEN = Color.rgb(31, 180, 118);
    private static final int PANEL = Color.rgb(10, 31, 61);
    private static final int PANEL_2 = Color.rgb(14, 40, 76);
    private static final int LINE = Color.rgb(42, 75, 116);

    private static final String DEFAULT_HOST = "127.0.0.1";
    private static final int DEFAULT_PORT = 1443;
    private static final int DEFAULT_CONNECT_TIMEOUT = 3500;
    private static final int DEFAULT_IDLE_TIMEOUT = 180000;

    private TextView stateText;
    private TextView hintText;
    private ImageButton mainButton;
    private Button settingsButton;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            refresh();
            handler.postDelayed(this, 4000);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
        }
        ensureDeviceSecret();
        buildUi();
        refresh();
        if (!prefs().getBoolean("onboarding_seen", false)) {
            handler.postDelayed(this::showOnboarding, 350);
        }
    }

    @Override protected void onResume() { super.onResume(); handler.post(tick); }
    @Override protected void onPause() { handler.removeCallbacks(tick); super.onPause(); }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackground(gradient(BG_TOP, BG_BOTTOM));

        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER);
        center.setPadding(dp(30), dp(36), dp(30), dp(36));

        TextView title = text("TG proxy", 34, TEXT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(-0.03f);
        center.addView(title, lp(-1, -2, 0, 0, 0, dp(5)));

        TextView sub = text("by Jr.Larzyk", 16, MUTED, Typeface.NORMAL);
        sub.setGravity(Gravity.CENTER);
        center.addView(sub, lp(-1, -2, 0, 0, 0, dp(64)));

        FrameLayout halo = new FrameLayout(this);
        halo.setBackground(oval(Color.argb(45, 0, 136, 204)));
        halo.setPadding(dp(22), dp(22), dp(22), dp(22));

        mainButton = new ImageButton(this);
        mainButton.setImageResource(getResources().getIdentifier("ic_telegram_plane", "drawable", getPackageName()));
        mainButton.setColorFilter(Color.WHITE);
        mainButton.setScaleType(ImageButton.ScaleType.CENTER);
        mainButton.setBackground(oval(PRIMARY));
        mainButton.setContentDescription("Запустить прокси");
        mainButton.setOnClickListener(v -> toggleProxy());
        halo.addView(mainButton, new FrameLayout.LayoutParams(dp(172), dp(172), Gravity.CENTER));
        center.addView(halo, lp(dp(218), dp(218), 0, 0, 0, dp(30)));

        stateText = text("Нажми, чтобы запустить", 20, TEXT, Typeface.BOLD);
        stateText.setGravity(Gravity.CENTER);
        center.addView(stateText, lp(-1, -2, 0, 0, 0, dp(8)));

        hintText = text("При первом запуске Telegram откроется автоматически", 14, MUTED, Typeface.NORMAL);
        hintText.setGravity(Gravity.CENTER);
        center.addView(hintText, lp(-1, -2, 0, 0, 0, dp(46)));

        settingsButton = flatButton("Настройки");
        settingsButton.setOnClickListener(v -> showSettings());
        center.addView(settingsButton, lp(dp(196), dp(52)));

        root.addView(center, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
    }

    private void toggleProxy() {
        String st = ProxyService.getStatus();
        if (st != null && st.startsWith("running")) stopProxy(); else startProxy(true);
    }

    private void startProxy(boolean openTelegramOnFirstButton) {
        SharedPreferences p = prefs();
        Intent i = new Intent(this, ProxyService.class);
        i.setAction(ProxyService.ACTION_START);
        i.putExtra(ProxyService.EXTRA_HOST, DEFAULT_HOST);
        i.putExtra(ProxyService.EXTRA_PORT, p.getInt("port", DEFAULT_PORT));
        i.putExtra(ProxyService.EXTRA_SECRET, getDeviceSecret());
        i.putExtra(ProxyService.EXTRA_CF_DOMAIN, p.getString("cf_domain", ""));
        i.putExtra(ProxyService.EXTRA_CONNECT_TIMEOUT, p.getInt("connect_timeout", DEFAULT_CONNECT_TIMEOUT));
        i.putExtra(ProxyService.EXTRA_IDLE_TIMEOUT, p.getInt("idle_timeout", DEFAULT_IDLE_TIMEOUT));
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        Toast.makeText(this, "Прокси запускается", Toast.LENGTH_SHORT).show();
        handler.postDelayed(this::refresh, 700);

        if (openTelegramOnFirstButton && !p.getBoolean("first_button_open_done", false)) {
            p.edit().putBoolean("first_button_open_done", true).apply();
            handler.postDelayed(this::openTelegram, 1400);
        }
    }

    private void stopProxy() {
        Intent i = new Intent(this, ProxyService.class);
        i.setAction(ProxyService.ACTION_STOP);
        startService(i);
        Toast.makeText(this, "Прокси остановлен", Toast.LENGTH_SHORT).show();
        handler.postDelayed(this::refresh, 400);
    }

    private void refresh() {
        String st = ProxyService.getStatus();
        boolean running = st != null && st.startsWith("running");
        if (running) {
            stateText.setText("Прокси работает");
            stateText.setTextColor(Color.rgb(120, 238, 182));
            hintText.setText("Telegram подключается через 127.0.0.1:" + prefs().getInt("port", DEFAULT_PORT));
            mainButton.setBackground(oval(GREEN));
            mainButton.setContentDescription("Остановить прокси");
        } else {
            stateText.setText("Нажми, чтобы запустить");
            stateText.setTextColor(TEXT);
            hintText.setText(prefs().getBoolean("first_button_open_done", false)
                    ? "После запуска открой Telegram из настроек"
                    : "При первом запуске Telegram откроется автоматически");
            mainButton.setBackground(oval(PRIMARY));
            mainButton.setContentDescription("Запустить прокси");
        }
    }

    private void showOnboarding() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(8), dp(18), dp(4));
        box.addView(onboardCard("1", "Запускаешь одной кнопкой", "Большая кнопка включает локальный прокси на телефоне. Ничего вручную вводить на главном экране не нужно."));
        box.addView(onboardCard("2", "Secret создаётся на устройстве", "При первом запуске приложение генерирует уникальный Secret и хранит его только на этом телефоне."));
        box.addView(onboardCard("3", "Telegram откроется сам", "Первое нажатие запускает прокси и открывает Telegram-ссылку, чтобы быстро добавить подключение."));
        box.addView(onboardCard("4", "Настройки под сеть", "В настройках можно поменять Cloudflare-домен, порт и таймауты подключения."));
        AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("Как это работает")
                .setView(box)
                .setPositiveButton("Понятно", (d, w) -> prefs().edit().putBoolean("onboarding_seen", true).apply())
                .create();
        dlg.setOnCancelListener(d -> prefs().edit().putBoolean("onboarding_seen", true).apply());
        dlg.show();
    }

    private View onboardCard(String n, String title, String body) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14), dp(13), dp(14), dp(13));
        card.setBackground(strokeRound(PANEL, LINE, dp(18), 1));

        TextView badge = text(n, 17, Color.WHITE, Typeface.BOLD);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(oval(PRIMARY));
        card.addView(badge, lp(dp(42), dp(42), 0, 0, dp(14), 0));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        TextView t = text(title, 15, TEXT, Typeface.BOLD);
        TextView b = text(body, 13, MUTED, Typeface.NORMAL);
        b.setLineSpacing(dp(2), 1.0f);
        texts.addView(t, lp(-1, -2, 0, 0, 0, dp(4)));
        texts.addView(b, lp(-1, -2));
        card.addView(texts, lp(0, -2, 1));
        LinearLayout.LayoutParams out = lp(-1, -2, 0, 0, 0, dp(10));
        card.setLayoutParams(out);
        return card;
    }

    private void showSettings() {
        SharedPreferences p = prefs();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(4), dp(16), dp(2));

        box.addView(settingsHeader("Подключение"));
        EditText port = input(String.valueOf(p.getInt("port", DEFAULT_PORT)), "1443", true);
        box.addView(settingsField("Локальный порт", "Порт для Telegram на этом телефоне", port));
        EditText domain = input(p.getString("cf_domain", ""), "example.com или пусто для авто", false);
        box.addView(settingsField("Cloudflare-домен", "Оставь пустым для автоматического списка доменов", domain));

        box.addView(settingsHeader("Таймауты"));
        EditText connectTimeout = input(String.valueOf(p.getInt("connect_timeout", DEFAULT_CONNECT_TIMEOUT)), "3500", true);
        box.addView(settingsField("Таймаут подключения, мс", "Рекомендуется 2500–5000. Меньше — быстрее переключается на рабочий домен.", connectTimeout));
        EditText idleTimeout = input(String.valueOf(p.getInt("idle_timeout", DEFAULT_IDLE_TIMEOUT)), "180000", true);
        box.addView(settingsField("Idle timeout, мс", "Рекомендуется 180000. Дольше держит живое соединение и уменьшает повторные подключения.", idleTimeout));

        box.addView(settingsHeader("Безопасность"));
        TextView secret = text("Secret устройства:\nsecret=dd" + getDeviceSecret(), 12, Color.rgb(188, 206, 232), Typeface.NORMAL);
        secret.setTextIsSelectable(true);
        secret.setPadding(dp(14), dp(12), dp(14), dp(12));
        secret.setBackground(strokeRound(PANEL_2, LINE, dp(16), 1));
        box.addView(secret, lp(-1, -2, 0, 0, 0, dp(10)));

        Button regen = dialogButton("Сгенерировать новый Secret");
        regen.setOnClickListener(v -> confirmRegenerateSecret());
        box.addView(regen, lp(-1, dp(48), 0, 0, 0, dp(10)));

        box.addView(settingsHeader("Действия"));
        Button open = dialogButton("Открыть Telegram");
        open.setOnClickListener(v -> openTelegram());
        box.addView(open, lp(-1, dp(48), 0, 0, 0, dp(10)));
        Button copy = dialogButton("Копировать ссылку");
        copy.setOnClickListener(v -> copyLink());
        box.addView(copy, lp(-1, dp(48), 0, 0, 0, dp(10)));
        Button logs = dialogButton("Показать логи");
        logs.setOnClickListener(v -> showLogs());
        box.addView(logs, lp(-1, dp(48)));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(box);

        AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("Настройки")
                .setView(scroll)
                .setNegativeButton("Закрыть", null)
                .setPositiveButton("Сохранить", null)
                .create();
        dlg.setOnShowListener(d -> dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            int savedPort = parseInt(port.getText().toString(), DEFAULT_PORT, 1, 65535);
            int savedConnect = parseInt(connectTimeout.getText().toString(), DEFAULT_CONNECT_TIMEOUT, 800, 15000);
            int savedIdle = parseInt(idleTimeout.getText().toString(), DEFAULT_IDLE_TIMEOUT, 0, 600000);
            p.edit()
                    .putInt("port", savedPort)
                    .putString("cf_domain", domain.getText().toString().trim())
                    .putInt("connect_timeout", savedConnect)
                    .putInt("idle_timeout", savedIdle)
                    .apply();
            Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show();
            dlg.dismiss();
        }));
        dlg.show();
    }

    private void confirmRegenerateSecret() {
        new AlertDialog.Builder(this)
                .setTitle("Новый Secret?")
                .setMessage("Telegram-ссылку нужно будет добавить заново. Текущий прокси будет остановлен.")
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Создать", (d, w) -> {
                    stopProxy();
                    prefs().edit().putString("device_secret", randomHex16()).putBoolean("first_button_open_done", false).apply();
                    Toast.makeText(this, "Secret обновлён", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void openTelegram() {
        String link = ProxyService.getLink();
        if (link == null || link.isEmpty()) {
            link = buildLocalLink();
        }
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(link))); }
        catch (Exception e) { Toast.makeText(this, "Telegram не открыл ссылку", Toast.LENGTH_SHORT).show(); }
    }

    private void copyLink() {
        String link = ProxyService.getLink();
        if (link == null || link.isEmpty()) link = buildLocalLink();
        ((ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("tg proxy", link));
        Toast.makeText(this, "Ссылка скопирована", Toast.LENGTH_SHORT).show();
    }

    private String buildLocalLink() {
        int port = prefs().getInt("port", DEFAULT_PORT);
        return "tg://proxy?server=127.0.0.1&port=" + port + "&secret=dd" + getDeviceSecret();
    }

    private void showLogs() {
        String l = ProxyService.getLogs();
        if (l == null || l.trim().isEmpty()) l = "Логов пока нет.";
        TextView t = text(l, 12, Color.rgb(190, 205, 230), Typeface.NORMAL);
        t.setTypeface(Typeface.MONOSPACE);
        t.setTextIsSelectable(true);
        t.setPadding(dp(16), dp(14), dp(16), dp(14));
        ScrollView s = new ScrollView(this);
        s.addView(t);
        new AlertDialog.Builder(this).setTitle("Логи").setView(s).setPositiveButton("OK", null).show();
    }

    private String getDeviceSecret() { return prefs().getString("device_secret", ensureDeviceSecret()); }
    private String ensureDeviceSecret() {
        SharedPreferences p = prefs();
        String s = p.getString("device_secret", "");
        if (s == null || !s.matches("[0-9a-f]{32}")) {
            s = randomHex16();
            p.edit().putString("device_secret", s).apply();
        }
        return s;
    }
    private static String randomHex16() {
        byte[] b = new byte[16];
        new SecureRandom().nextBytes(b);
        char[] h = "0123456789abcdef".toCharArray();
        char[] out = new char[32];
        for (int i = 0; i < b.length; i++) { int v = b[i] & 0xff; out[i*2]=h[v>>>4]; out[i*2+1]=h[v&15]; }
        return new String(out);
    }

    private SharedPreferences prefs() { return getSharedPreferences("tg_proxy_settings", MODE_PRIVATE); }
    private int parseInt(String s, int def, int min, int max) {
        try { int v = Integer.parseInt(s.trim()); if (v < min) return min; if (v > max) return max; return v; }
        catch (Exception e) { return def; }
    }

    private TextView settingsHeader(String s) {
        TextView v = text(s.toUpperCase(Locale.US), 12, Color.rgb(103, 189, 255), Typeface.BOLD);
        v.setLetterSpacing(0.12f);
        v.setPadding(0, dp(14), 0, dp(8));
        return v;
    }

    private View settingsField(String title, String desc, EditText input) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackground(strokeRound(PANEL, LINE, dp(18), 1));
        TextView t = text(title, 15, TEXT, Typeface.BOLD);
        TextView d = text(desc, 12, MUTED, Typeface.NORMAL);
        d.setLineSpacing(dp(2), 1.0f);
        card.addView(t, lp(-1, -2, 0, 0, 0, dp(3)));
        card.addView(d, lp(-1, -2, 0, 0, 0, dp(8)));
        card.addView(input, lp(-1, dp(48)));
        return cardWithMargin(card);
    }

    private View cardWithMargin(View v) {
        v.setLayoutParams(lp(-1, -2, 0, 0, 0, dp(10)));
        return v;
    }

    private EditText input(String value, String hint, boolean number) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setHint(hint);
        e.setTextSize(15);
        e.setSingleLine(true);
        e.setImeOptions(EditorInfo.IME_ACTION_DONE);
        e.setTextColor(TEXT);
        e.setHintTextColor(Color.rgb(102, 126, 158));
        e.setPadding(dp(12), 0, dp(12), 0);
        e.setBackground(strokeRound(Color.rgb(5, 18, 39), Color.rgb(37, 68, 108), dp(14), 1));
        if (number) e.setInputType(InputType.TYPE_CLASS_NUMBER);
        return e;
    }

    private Button flatButton(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(TEXT);
        b.setTextSize(16);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setBackground(strokeRound(Color.argb(70, 9, 24, 48), LINE, dp(26), 1));
        return b;
    }

    private Button dialogButton(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(15);
        b.setAllCaps(false);
        return b;
    }

    private TextView text(String s, int sp, int color, int style) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(Typeface.DEFAULT, style);
        return v;
    }

    private GradientDrawable gradient(int top, int bottom) {
        return new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{top, bottom});
    }
    private GradientDrawable oval(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }
    private GradientDrawable strokeRound(int fill, int stroke, int radius, int width) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radius);
        g.setStroke(dp(width), stroke);
        return g;
    }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private LinearLayout.LayoutParams lp(int w, int h, float weight) { return new LinearLayout.LayoutParams(w, h, weight); }
    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(l, t, r, b);
        return p;
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
