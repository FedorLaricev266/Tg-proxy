package com.example.tgwsproxy;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/**
 * Native Java MTProto-over-WebSocket bridge.
 *
 * This keeps the anti-blocking path of the original tg-ws-proxy:
 * Telegram app -> local MTProxy -> WSS Cloudflare domain -> Telegram web DC.
 *
 * The slow Python/Chaquopy/pyaes hot path is removed. AES-CTR is done by Android
 * javax.crypto and WebSocket framing is implemented directly in Java.
 */
public final class FastMtprotoProxy {
    private static final int HANDSHAKE_LEN = 64;
    private static final int SKIP_LEN = 8;
    private static final int PREKEY_LEN = 32;
    private static final int KEY_LEN = 32;
    private static final int IV_LEN = 16;
    private static final int PROTO_TAG_POS = 56;
    private static final int DC_IDX_POS = 60;
    private static final int PROTO_ABRIDGED_INT = 0xEFEFEFEF;
    private static final int PROTO_INTERMEDIATE_INT = 0xEEEEEEEE;
    private static final int PROTO_PADDED_INTERMEDIATE_INT = 0xDDDDDDDD;
    private static final byte[] ZERO_64 = new byte[64];
    private static final byte[] PROTO_ABRIDGED = new byte[]{(byte)0xef,(byte)0xef,(byte)0xef,(byte)0xef};
    private static final byte[] PROTO_INTERMEDIATE = new byte[]{(byte)0xee,(byte)0xee,(byte)0xee,(byte)0xee};
    private static final byte[] PROTO_SECURE = new byte[]{(byte)0xdd,(byte)0xdd,(byte)0xdd,(byte)0xdd};

    private static final String[] DEFAULT_CF_DOMAINS = new String[]{
            "pclead.co.uk", "offshor.co.uk", "cakeisalie.co.uk", "noskomnadzor.co.uk",
            "lovetrue.co.uk", "sorokdva.co.uk", "pyatdesyatdva.co.uk", "kartoshka.co.uk",
            "sorokodin.co.uk", "pyatdesyatodin.co.uk"
    };

    // Bounded elastic pool: idle worker threads die quickly, so the proxy doesn't
    // keep the CPU awake when there are no active Telegram connections.
    private final ExecutorService pool = new ThreadPoolExecutor(0, 64, 45L, TimeUnit.SECONDS, new SynchronousQueue<>(), r -> {
        Thread t = new Thread(r, "tg-ws-native-proxy");
        t.setDaemon(true);
        t.setPriority(Thread.NORM_PRIORITY);
        return t;
    });
    private final SecureRandom random = new SecureRandom();
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final AtomicInteger active = new AtomicInteger(0);
    private final StringBuilder log = new StringBuilder();
    private final Map<Integer, String> preferredBaseByDc = Collections.synchronizedMap(new HashMap<>());

    private ServerSocket serverSocket;
    private Thread acceptThread;
    private byte[] secretBytes;
    private String secretHex;
    private String host;
    private int port;
    private String userCfDomain = "";
    private int connectTimeoutMs = 3500;
    private int idleTimeoutMs = 180000;

    public synchronized String start(String host, int port, String secret) throws Exception {
        return start(host, port, secret, "");
    }

    public synchronized String start(String host, int port, String secret, String cfDomain) throws Exception {
        return start(host, port, secret, cfDomain, 3500, 180000);
    }

    public synchronized String start(String host, int port, String secret, String cfDomain, int connectTimeoutMs, int idleTimeoutMs) throws Exception {
        if (running.get()) return getLink();
        this.host = (host == null || host.trim().isEmpty()) ? "127.0.0.1" : host.trim();
        this.port = port <= 0 ? 1443 : port;
        this.userCfDomain = normalizeDomain(cfDomain);
        this.connectTimeoutMs = clamp(connectTimeoutMs, 800, 15000, 3500);
        this.idleTimeoutMs = clamp(idleTimeoutMs, 0, 600000, 180000);
        setSecret(secret);

        serverSocket = new ServerSocket();
        serverSocket.setReuseAddress(true);
        serverSocket.bind(new InetSocketAddress(InetAddress.getByName(this.host), this.port), 256);
        running.set(true);
        acceptThread = new Thread(this::acceptLoop, "tg-ws-native-accept");
        acceptThread.setDaemon(true);
        acceptThread.start();
        appendLog("Native WS/Cloudflare proxy started on " + this.host + ":" + this.port);
        appendLog("Mode: bypass via WSS Cloudflare domains, no Python/Chaquopy");
        appendLog("Performance profile: TCP_NODELAY, large socket buffers, native AES, compact logs");
        appendLog("CF domain: " + (this.userCfDomain.isEmpty() ? "auto pool" : this.userCfDomain));
        appendLog("Timeouts: connect=" + this.connectTimeoutMs + "ms, idle=" + this.idleTimeoutMs + "ms");
        appendLog("Telegram link uses secret=dd" + secretHex);
        return getLink();
    }

    public synchronized void stop() {
        running.set(false);
        try { if (serverSocket != null) serverSocket.close(); } catch (Exception ignored) {}
        appendLog("Proxy stopped");
    }

    public String getLink() {
        if (secretHex == null) return "";
        String linkHost = "0.0.0.0".equals(host) ? "127.0.0.1" : host;
        return "tg://proxy?server=" + linkHost + "&port=" + port + "&secret=dd" + secretHex;
    }

    public String getStatus() {
        return running.get()
                ? ("running WS/CF, active=" + active.get() + ", " + host + ":" + port)
                : "stopped";
    }

    public synchronized String getLogs() { return log.toString(); }

    private void acceptLoop() {
        while (running.get()) {
            try {
                Socket client = serverSocket.accept();
                client.setTcpNoDelay(true);
                client.setKeepAlive(true);
                client.setSoTimeout(idleTimeoutMs);
                client.setReceiveBufferSize(256 * 1024);
                client.setSendBufferSize(256 * 1024);
                client.setPerformancePreferences(0, 2, 1);
                pool.execute(() -> handleClient(client));
            } catch (SocketException se) {
                if (running.get()) appendLog("Accept socket error: " + se.getMessage());
            } catch (Exception e) {
                appendLog("Accept error: " + e.getMessage());
            }
        }
    }

    private void handleClient(Socket client) {
        active.incrementAndGet();
        RawWebSocket ws = null;
        String label = String.valueOf(client.getRemoteSocketAddress());
        try {
            InputStream cin = client.getInputStream();
            OutputStream cout = client.getOutputStream();
            byte[] handshake = readExactly(cin, HANDSHAKE_LEN);
            HandshakeInfo hi = tryHandshake(handshake);
            if (hi == null) {
                appendLog(label + " bad handshake / wrong secret");
                return;
            }

            int protoInt = protoInt(hi.protoTag);
            int dcIdx = hi.media ? -hi.dc : hi.dc;
            byte[] relayInit = generateRelayInit(hi.protoTag, dcIdx);
            CryptoCtx ctx = buildCryptoCtx(hi.clientPrekeyIv, relayInit);
            MsgSplitter splitter = new MsgSplitter(relayInit, protoInt);

            ws = connectWsForDc(hi.dc, hi.media);
            ws.send(relayInit);
            appendLog(label + " DC" + hi.dc + (hi.media ? " media" : "") + " -> WSS " + ws.domain);
            bridgeClientToWs(client, cin, cout, ws, ctx, splitter);
        } catch (Exception e) {
            appendLog(label + " error: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        } finally {
            if (ws != null) ws.closeQuiet();
            closeQuiet(client);
            active.decrementAndGet();
        }
    }

    private RawWebSocket connectWsForDc(int dc, boolean media) throws Exception {
        List<String> candidates = new ArrayList<>();
        String preferred = preferredBaseByDc.get(dc);
        if (preferred != null && !preferred.isEmpty()) candidates.add(preferred);
        if (!userCfDomain.isEmpty()) {
            if (!candidates.contains(userCfDomain)) candidates.add(userCfDomain);
        } else {
            List<String> shuffled = new ArrayList<>(Arrays.asList(DEFAULT_CF_DOMAINS));
            Collections.shuffle(shuffled, random);
            for (String d : shuffled) if (!candidates.contains(d)) candidates.add(d);
        }

        Exception last = null;
        for (String base : candidates) {
            String domain = domainForDc(base, dc, media);
            try {
                RawWebSocket ws = RawWebSocket.connect(domain, "/apiws", connectTimeoutMs, idleTimeoutMs);
                preferredBaseByDc.put(dc, base);
                return ws;
            } catch (Exception e) {
                last = e;
                appendLog("WSS failed " + domain + ": " + e.getMessage());
            }
        }
        throw new IOException("all WSS/CF domains failed" + (last != null ? ": " + last.getMessage() : ""));
    }

    private static String domainForDc(String base, int dc, boolean media) {
        String b = base.trim().toLowerCase(Locale.US);
        if (b.contains("{dc}")) return b.replace("{dc}", String.valueOf(dc));
        if (b.startsWith("kws")) return b;
        // Original tg-ws-proxy CF fallback uses kws<dc>.<base>.
        return "kws" + dc + "." + b;
    }

    private void bridgeClientToWs(Socket client, InputStream cin, OutputStream cout, RawWebSocket ws, CryptoCtx ctx, MsgSplitter splitter) throws InterruptedException {
        AtomicBoolean done = new AtomicBoolean(false);
        Thread up = new Thread(() -> tcpToWs(cin, ws, ctx.clientDec, ctx.telegramEnc, splitter, done), "tg-tcp-to-ws");
        Thread down = new Thread(() -> wsToTcp(ws, cout, ctx.telegramDec, ctx.clientEnc, done), "tg-ws-to-tcp");
        up.setDaemon(true); down.setDaemon(true);
        up.start(); down.start();
        while (!done.get() && running.get()) Thread.sleep(20);
        done.set(true);
        ws.closeQuiet();
        closeQuiet(client);
        up.join(150);
        down.join(150);
    }

    private void tcpToWs(InputStream in, RawWebSocket ws, Cipher decrypt, Cipher encrypt, MsgSplitter splitter, AtomicBoolean done) {
        byte[] buf = new byte[128 * 1024];
        try {
            while (!done.get() && running.get()) {
                int n = in.read(buf);
                if (n < 0) break;
                if (n == 0) continue;
                byte[] plain = decrypt.update(buf, 0, n);
                byte[] enc = encrypt.update(plain);
                List<byte[]> frames = splitter.split(enc);
                for (byte[] frame : frames) ws.send(frame);
            }
            for (byte[] tail : splitter.flush()) ws.send(tail);
        } catch (Exception ignored) {
        } finally {
            done.set(true);
        }
    }

    private void wsToTcp(RawWebSocket ws, OutputStream out, Cipher decrypt, Cipher encrypt, AtomicBoolean done) {
        try {
            while (!done.get() && running.get()) {
                byte[] data = ws.recv();
                if (data == null) break;
                byte[] plain = decrypt.update(data);
                byte[] enc = encrypt.update(plain);
                out.write(enc);
                out.flush();
            }
        } catch (Exception ignored) {
        } finally {
            done.set(true);
        }
    }

    private HandshakeInfo tryHandshake(byte[] handshake) throws Exception {
        byte[] prekeyIv = Arrays.copyOfRange(handshake, SKIP_LEN, SKIP_LEN + PREKEY_LEN + IV_LEN);
        byte[] prekey = Arrays.copyOfRange(prekeyIv, 0, PREKEY_LEN);
        byte[] iv = Arrays.copyOfRange(prekeyIv, PREKEY_LEN, PREKEY_LEN + IV_LEN);
        byte[] key = sha256(concat(prekey, secretBytes));
        Cipher dec = aesCtr(key, iv);
        byte[] plain = dec.update(handshake);
        byte[] tag = Arrays.copyOfRange(plain, PROTO_TAG_POS, PROTO_TAG_POS + 4);
        if (!Arrays.equals(tag, PROTO_ABRIDGED) && !Arrays.equals(tag, PROTO_INTERMEDIATE) && !Arrays.equals(tag, PROTO_SECURE)) return null;
        int dcIdx = (short)((plain[DC_IDX_POS] & 0xff) | ((plain[DC_IDX_POS + 1] & 0xff) << 8));
        int dc = Math.abs(dcIdx);
        boolean media = dcIdx < 0;
        return new HandshakeInfo(dc, media, tag, prekeyIv);
    }

    private byte[] generateRelayInit(byte[] protoTag, int dcIdx) throws Exception {
        byte[] rnd = new byte[HANDSHAKE_LEN];
        while (true) {
            random.nextBytes(rnd);
            if ((rnd[0] & 0xff) == 0xef) continue;
            int first4 = ((rnd[0] & 0xff) << 24) | ((rnd[1] & 0xff) << 16) | ((rnd[2] & 0xff) << 8) | (rnd[3] & 0xff);
            if (first4 == 0x48454144 || first4 == 0x504f5354 || first4 == 0x47455420 || first4 == 0xeeeeeeee || first4 == 0xdddddddd || first4 == 0x16030102) continue;
            if (rnd[4] == 0 && rnd[5] == 0 && rnd[6] == 0 && rnd[7] == 0) continue;
            break;
        }
        byte[] encKey = Arrays.copyOfRange(rnd, SKIP_LEN, SKIP_LEN + KEY_LEN);
        byte[] encIv = Arrays.copyOfRange(rnd, SKIP_LEN + KEY_LEN, SKIP_LEN + KEY_LEN + IV_LEN);
        Cipher enc = aesCtr(encKey, encIv);
        byte[] encryptedFull = enc.update(rnd);

        byte[] tailPlain = new byte[8];
        System.arraycopy(protoTag, 0, tailPlain, 0, 4);
        tailPlain[4] = (byte)(dcIdx & 0xff);
        tailPlain[5] = (byte)((dcIdx >> 8) & 0xff);
        tailPlain[6] = (byte)random.nextInt(256);
        tailPlain[7] = (byte)random.nextInt(256);

        byte[] out = Arrays.copyOf(rnd, rnd.length);
        for (int i = 0; i < 8; i++) {
            byte ks = (byte)(encryptedFull[PROTO_TAG_POS + i] ^ rnd[PROTO_TAG_POS + i]);
            out[PROTO_TAG_POS + i] = (byte)(tailPlain[i] ^ ks);
        }
        return out;
    }

    private CryptoCtx buildCryptoCtx(byte[] clientPrekeyIv, byte[] relayInit) throws Exception {
        byte[] cltDecPrekey = Arrays.copyOfRange(clientPrekeyIv, 0, PREKEY_LEN);
        byte[] cltDecIv = Arrays.copyOfRange(clientPrekeyIv, PREKEY_LEN, PREKEY_LEN + IV_LEN);
        byte[] cltDecKey = sha256(concat(cltDecPrekey, secretBytes));

        byte[] rev = reverse(clientPrekeyIv);
        byte[] cltEncKey = sha256(concat(Arrays.copyOfRange(rev, 0, PREKEY_LEN), secretBytes));
        byte[] cltEncIv = Arrays.copyOfRange(rev, PREKEY_LEN, PREKEY_LEN + IV_LEN);

        Cipher cltDec = aesCtr(cltDecKey, cltDecIv);
        Cipher cltEnc = aesCtr(cltEncKey, cltEncIv);
        cltDec.update(ZERO_64);

        byte[] relayEncKey = Arrays.copyOfRange(relayInit, SKIP_LEN, SKIP_LEN + KEY_LEN);
        byte[] relayEncIv = Arrays.copyOfRange(relayInit, SKIP_LEN + KEY_LEN, SKIP_LEN + KEY_LEN + IV_LEN);
        byte[] relayRev = reverse(Arrays.copyOfRange(relayInit, SKIP_LEN, SKIP_LEN + KEY_LEN + IV_LEN));
        byte[] relayDecKey = Arrays.copyOfRange(relayRev, 0, KEY_LEN);
        byte[] relayDecIv = Arrays.copyOfRange(relayRev, KEY_LEN, KEY_LEN + IV_LEN);
        Cipher tgEnc = aesCtr(relayEncKey, relayEncIv);
        Cipher tgDec = aesCtr(relayDecKey, relayDecIv);
        tgEnc.update(ZERO_64);
        return new CryptoCtx(cltDec, cltEnc, tgEnc, tgDec);
    }

    private void setSecret(String secret) {
        String s = secret == null ? "" : secret.trim().toLowerCase(Locale.US);
        if (s.startsWith("dd") && s.length() >= 34) s = s.substring(2);
        if (s.startsWith("ee") && s.length() >= 34) s = s.substring(2);
        if (!s.matches("[0-9a-f]{32}")) {
            byte[] b = new byte[16];
            random.nextBytes(b);
            s = toHex(b);
        }
        secretHex = s;
        secretBytes = fromHex(s);
    }

    private static int protoInt(byte[] tag) {
        if (Arrays.equals(tag, PROTO_ABRIDGED)) return PROTO_ABRIDGED_INT;
        if (Arrays.equals(tag, PROTO_INTERMEDIATE)) return PROTO_INTERMEDIATE_INT;
        return PROTO_PADDED_INTERMEDIATE_INT;
    }

    private static String normalizeDomain(String d) {
        if (d == null) return "";
        String s = d.trim().toLowerCase(Locale.US);
        if (s.startsWith("https://")) s = s.substring(8);
        if (s.startsWith("http://")) s = s.substring(7);
        int slash = s.indexOf('/');
        if (slash >= 0) s = s.substring(0, slash);
        return s;
    }

    private static int clamp(int v, int min, int max, int def) {
        if (v < min) return min;
        if (v > max) return max;
        return v;
    }

    private static Cipher aesCtr(byte[] key, byte[] iv) throws Exception {
        Cipher c = Cipher.getInstance("AES/CTR/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(iv));
        return c;
    }

    private static byte[] sha256(byte[] data) throws Exception { return MessageDigest.getInstance("SHA-256").digest(data); }
    private static byte[] concat(byte[] a, byte[] b) { byte[] out = new byte[a.length + b.length]; System.arraycopy(a,0,out,0,a.length); System.arraycopy(b,0,out,a.length,b.length); return out; }
    private static byte[] reverse(byte[] in) { byte[] out = new byte[in.length]; for (int i=0;i<in.length;i++) out[i]=in[in.length-1-i]; return out; }
    private static byte[] readExactly(InputStream in, int len) throws IOException { byte[] out = new byte[len]; int off=0; while (off<len) { int n=in.read(out,off,len-off); if (n<0) throw new EOFException("closed while reading " + len + " bytes"); off+=n; } return out; }
    private static void closeQuiet(Socket s) { if (s != null) try { s.close(); } catch (Exception ignored) {} }
    private static byte[] fromHex(String s) { byte[] out = new byte[s.length()/2]; for (int i=0;i<out.length;i++) out[i]=(byte)Integer.parseInt(s.substring(i*2,i*2+2),16); return out; }
    private static String toHex(byte[] b) { char[] hex="0123456789abcdef".toCharArray(); char[] out=new char[b.length*2]; for(int i=0;i<b.length;i++){int v=b[i]&0xff;out[i*2]=hex[v>>>4];out[i*2+1]=hex[v&15];} return new String(out); }

    private synchronized void appendLog(String s) {
        // Keep logging compact: timestamp formatting in the hot path adds overhead on Android.
        log.append(s).append('\n');
        int max = 7000; if (log.length() > max) log.delete(0, log.length() - max);
    }

    private static final class HandshakeInfo {
        final int dc; final boolean media; final byte[] protoTag; final byte[] clientPrekeyIv;
        HandshakeInfo(int dc, boolean media, byte[] protoTag, byte[] clientPrekeyIv) { this.dc=dc; this.media=media; this.protoTag=protoTag; this.clientPrekeyIv=clientPrekeyIv; }
    }
    private static final class CryptoCtx {
        final Cipher clientDec, clientEnc, telegramEnc, telegramDec;
        CryptoCtx(Cipher clientDec, Cipher clientEnc, Cipher telegramEnc, Cipher telegramDec) { this.clientDec=clientDec; this.clientEnc=clientEnc; this.telegramEnc=telegramEnc; this.telegramDec=telegramDec; }
    }

    private static final class MsgSplitter {
        private final Cipher dec;
        private final int proto;
        private final ByteArrayOutputStream cipherBuf = new ByteArrayOutputStream();
        private final ByteArrayOutputStream plainBuf = new ByteArrayOutputStream();
        private boolean disabled = false;

        MsgSplitter(byte[] relayInit, int proto) throws Exception {
            this.dec = aesCtr(Arrays.copyOfRange(relayInit, 8, 40), Arrays.copyOfRange(relayInit, 40, 56));
            this.dec.update(ZERO_64);
            this.proto = proto;
        }

        synchronized List<byte[]> split(byte[] chunk) throws Exception {
            if (chunk == null || chunk.length == 0) return Collections.emptyList();
            if (disabled) return Collections.singletonList(chunk);
            cipherBuf.write(chunk);
            byte[] p = dec.update(chunk);
            plainBuf.write(p);
            ArrayList<byte[]> parts = new ArrayList<>();
            while (cipherBuf.size() > 0) {
                Integer packetLen = nextPacketLen();
                if (packetLen == null) break;
                if (packetLen <= 0) {
                    parts.add(cipherBuf.toByteArray());
                    cipherBuf.reset(); plainBuf.reset(); disabled = true; break;
                }
                byte[] c = cipherBuf.toByteArray();
                byte[] pl = plainBuf.toByteArray();
                parts.add(Arrays.copyOfRange(c, 0, packetLen));
                cipherBuf.reset(); plainBuf.reset();
                if (c.length > packetLen) cipherBuf.write(c, packetLen, c.length - packetLen);
                if (pl.length > packetLen) plainBuf.write(pl, packetLen, pl.length - packetLen);
            }
            return parts;
        }

        synchronized List<byte[]> flush() {
            if (cipherBuf.size() == 0) return Collections.emptyList();
            byte[] tail = cipherBuf.toByteArray();
            cipherBuf.reset(); plainBuf.reset();
            return Collections.singletonList(tail);
        }

        private Integer nextPacketLen() {
            byte[] p = plainBuf.toByteArray();
            if (p.length == 0) return null;
            if (proto == PROTO_ABRIDGED_INT) return nextAbridgedLen(p);
            if (proto == PROTO_INTERMEDIATE_INT || proto == PROTO_PADDED_INTERMEDIATE_INT) return nextIntermediateLen(p);
            return 0;
        }

        private Integer nextAbridgedLen(byte[] p) {
            int first = p[0] & 0xff;
            int payloadLen, headerLen;
            if (first == 0x7f || first == 0xff) {
                if (p.length < 4) return null;
                payloadLen = ((p[1] & 0xff) | ((p[2] & 0xff) << 8) | ((p[3] & 0xff) << 16)) * 4;
                headerLen = 4;
            } else {
                payloadLen = (first & 0x7f) * 4;
                headerLen = 1;
            }
            if (payloadLen <= 0) return 0;
            int packetLen = headerLen + payloadLen;
            return p.length < packetLen ? null : packetLen;
        }

        private Integer nextIntermediateLen(byte[] p) {
            if (p.length < 4) return null;
            int payloadLen = (p[0] & 0xff) | ((p[1] & 0xff) << 8) | ((p[2] & 0xff) << 16) | ((p[3] & 0x7f) << 24);
            if (payloadLen <= 0) return 0;
            int packetLen = 4 + payloadLen;
            return p.length < packetLen ? null : packetLen;
        }
    }

    private static final class RawWebSocket {
        final SSLSocket socket;
        final InputStream in;
        final OutputStream out;
        final String domain;
        volatile boolean closed = false;

        RawWebSocket(SSLSocket socket, String domain) throws IOException {
            this.socket = socket; this.domain = domain;
            this.in = socket.getInputStream(); this.out = socket.getOutputStream();
        }

        static RawWebSocket connect(String domain, String path, int timeoutMs, int idleTimeoutMs) throws Exception {
            String d = normalizeDomain(domain);
            SSLSocketFactory sf = (SSLSocketFactory) SSLSocketFactory.getDefault();
            SSLSocket s = (SSLSocket) sf.createSocket();
            s.setTcpNoDelay(true); s.setKeepAlive(true); s.setSoTimeout(timeoutMs);
            s.setReceiveBufferSize(256 * 1024);
            s.setSendBufferSize(256 * 1024);
            s.setPerformancePreferences(0, 2, 1);
            s.connect(new InetSocketAddress(d, 443), timeoutMs);
            s.startHandshake();
            RawWebSocket ws = new RawWebSocket(s, d);
            ws.handshake(path == null ? "/apiws" : path);
            s.setSoTimeout(idleTimeoutMs);
            return ws;
        }

        void handshake(String path) throws Exception {
            byte[] key = new byte[16]; WS_RANDOM.nextBytes(key);
            String wsKey = android.util.Base64.encodeToString(key, android.util.Base64.NO_WRAP);
            String req = "GET " + path + " HTTP/1.1\r\n" +
                    "Host: " + domain + "\r\n" +
                    "Upgrade: websocket\r\n" +
                    "Connection: Upgrade\r\n" +
                    "Sec-WebSocket-Key: " + wsKey + "\r\n" +
                    "Sec-WebSocket-Version: 13\r\n" +
                    "Sec-WebSocket-Protocol: binary\r\n\r\n";
            out.write(req.getBytes("US-ASCII")); out.flush();
            String status = readHttpLine(in);
            if (status == null || !status.contains(" 101 ")) {
                while (true) { String line = readHttpLine(in); if (line == null || line.length() == 0) break; }
                closeQuiet();
                throw new IOException(status == null ? "empty HTTP response" : status);
            }
            while (true) { String line = readHttpLine(in); if (line == null || line.length() == 0) break; }
        }

        synchronized void send(byte[] payload) throws IOException {
            if (closed) throw new IOException("WebSocket closed");
            writeFrame(0x2, payload, true); out.flush();
        }

        byte[] recv() throws IOException {
            while (!closed) {
                int b0 = in.read(); if (b0 < 0) return null;
                int b1 = in.read(); if (b1 < 0) return null;
                int opcode = b0 & 0x0f;
                int len = b1 & 0x7f;
                if (len == 126) len = readU16(in);
                else if (len == 127) {
                    long l = readU64(in); if (l > Integer.MAX_VALUE) throw new IOException("WS frame too large"); len = (int) l;
                }
                byte[] mask = null;
                if ((b1 & 0x80) != 0) mask = readExactly(in, 4);
                byte[] payload = readExactly(in, len);
                if (mask != null) xorMask(payload, mask);
                if (opcode == 0x8) { closed = true; return null; }
                if (opcode == 0x9) { synchronized (this) { writeFrame(0xA, payload, true); out.flush(); } continue; }
                if (opcode == 0xA) continue;
                if (opcode == 0x1 || opcode == 0x2) return payload;
            }
            return null;
        }

        private void writeFrame(int opcode, byte[] data, boolean mask) throws IOException {
            int len = data == null ? 0 : data.length;
            out.write(0x80 | opcode);
            if (len < 126) out.write((mask ? 0x80 : 0) | len);
            else if (len < 65536) { out.write((mask ? 0x80 : 0) | 126); out.write((len >>> 8) & 0xff); out.write(len & 0xff); }
            else { out.write((mask ? 0x80 : 0) | 127); for (int i=7;i>=0;i--) out.write((int)(((long)len >>> (8*i)) & 0xff)); }
            if (mask) {
                byte[] m = new byte[4]; WS_RANDOM.nextBytes(m); out.write(m);
                byte[] copy = Arrays.copyOf(data, len); xorMask(copy, m); out.write(copy);
            } else if (len > 0) out.write(data);
        }

        void closeQuiet() { closed = true; try { socket.close(); } catch (Exception ignored) {} }
    }

    private static final SecureRandom WS_RANDOM = new SecureRandom();

    private static String readHttpLine(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        while (true) {
            int c = in.read(); if (c < 0) return b.size() == 0 ? null : b.toString("UTF-8");
            if (c == '\n') break;
            if (c != '\r') b.write(c);
        }
        return b.toString("UTF-8");
    }
    private static int readU16(InputStream in) throws IOException { return ((in.read() & 0xff) << 8) | (in.read() & 0xff); }
    private static long readU64(InputStream in) throws IOException { long v=0; for(int i=0;i<8;i++) v=(v<<8)|(in.read()&0xff); return v; }
    private static void xorMask(byte[] data, byte[] mask) { for (int i=0;i<data.length;i++) data[i] = (byte)(data[i] ^ mask[i & 3]); }
}
