# Security

Do not publish private signing keys, keystores, or personal Cloudflare credentials.

The device Secret is generated locally on first launch and should not be shared publicly.
