# Energy saving changes

This build keeps the same UI and proxy path, but reduces idle battery drain:

- No Python/Chaquopy runtime in the hot path.
- Android AES is used through `javax.crypto.Cipher`.
- Foreground notification uses low/min importance and `setOnlyAlertOnce`.
- UI log/status polling was slowed from ~1.2s to ~3.5s and updates text only when changed.
- Proxy worker threads are now bounded and idle threads are destroyed after 15 seconds.
- Socket buffers are compact to avoid unnecessary memory and radio churn.
- Logs are capped to 12 KB instead of 24 KB.

Recommended user setting: disable battery optimization for the app only if Android kills the service in background. Otherwise leave battery optimization enabled for lower consumption.
