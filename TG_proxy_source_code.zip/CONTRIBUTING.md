# Contributing

Pull requests are welcome.

Before sending a PR:

1. Make sure the project builds with `./gradlew assembleDebug`.
2. Do not commit build outputs, APK files, keystores, or local properties.
3. Keep proxy performance in mind: avoid extra logging or sleeps in the hot path.
